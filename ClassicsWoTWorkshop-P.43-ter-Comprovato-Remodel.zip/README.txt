Thank you for downloading! To install, drag the included .wotmod files to <Your WoT Directory\mods\<Game Version>

(Example: C:\Games\World_of_Tanks\mods\1.7.1.2)


==== OPTIONAL ====


OPTIONAL: If you use Zorgane's Gun Sound mod, open the "Sound fix" folder and drag the included "scripts" folder to <Your WoT Directory\RES_mods\<Game Version>. 

(Example: C:\Games\World_of_Tanks\RES_mods\1.7.1.2)


Made by FastestClassic.